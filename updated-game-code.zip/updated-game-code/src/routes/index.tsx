import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, useCallback } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MalwareBuster 95 — Save the Net!" },
      { name: "description", content: "Retro Win95 ray gun shooter. Click viruses to save the web." },
    ],
  }),
  component: Game,
});

// ---------- Pixel/SVG art ----------
function HeroSprite({ size = 48 }: { size?: number }) {
  // Low-poly PS1-style green alien (flat shaded polygons)
  return (
    <svg width={size} height={size * 1.4} viewBox="0 0 100 140">
      <g stroke="#1d3a1d" strokeWidth="0.6" strokeLinejoin="miter">
        {/* Antennae */}
        <polygon points="28,18 32,4 36,6 34,20" fill="#3d6b30" />
        <polygon points="36,6 40,2 44,8 34,20" fill="#4f8a3f" />
        <polygon points="64,20 66,6 70,4 72,18" fill="#3d6b30" />
        <polygon points="70,4 74,2 76,8 72,18" fill="#4f8a3f" />
        {/* Antenna tips */}
        <polygon points="36,2 44,2 44,8 40,10 36,8" fill="#5a9a48" />
        <polygon points="70,2 76,2 76,8 73,10 70,8" fill="#5a9a48" />
        {/* Head - faceted */}
        <polygon points="50,14 28,30 22,55 50,72 78,55 72,30" fill="#4f8a3f" />
        <polygon points="50,14 72,30 78,55 50,60" fill="#3d6b30" />
        <polygon points="22,55 50,72 50,60" fill="#5a9a48" />
        <polygon points="50,60 78,55 50,72" fill="#467a36" />
        {/* Eyes - big black almond */}
        <polygon points="30,42 44,40 46,48 32,52" fill="#0a0a0a" />
        <polygon points="54,40 68,42 66,52 52,48" fill="#0a0a0a" />
        {/* Neck */}
        <polygon points="42,72 58,72 56,82 44,82" fill="#3d6b30" />
        {/* Body - shoulders and torso faceted */}
        <polygon points="44,82 30,90 26,108 42,102" fill="#4f8a3f" />
        <polygon points="56,82 70,90 74,108 58,102" fill="#3d6b30" />
        <polygon points="44,82 56,82 58,102 42,102" fill="#5a9a48" />
        {/* Shoulder spikes */}
        <polygon points="26,108 18,118 30,112" fill="#3d6b30" />
        <polygon points="74,108 82,118 70,112" fill="#3d6b30" />
        {/* Legs / lower body tatters */}
        <polygon points="42,102 38,124 44,138 48,120" fill="#4f8a3f" />
        <polygon points="58,102 62,124 56,138 52,120" fill="#3d6b30" />
        <polygon points="48,120 52,120 50,134" fill="#5a9a48" />
        {/* Ray gun (pastel) */}
        <polygon points="74,90 92,92 94,100 76,98" fill="#d8d8e4" />
        <polygon points="92,92 98,94 96,100 94,100" fill="#b4f0a0" />
        <polygon points="74,98 80,104 78,108 72,104" fill="#a8a8b8" />
      </g>
    </svg>
  );
}

function VirusBlob({ size = 56 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64">
      <g fill="#1a0a2a" stroke="#000" strokeWidth="1.5">
        <polygon points="32,4 38,18 52,10 46,24 60,28 46,34 54,48 38,44 34,60 28,46 14,54 20,38 4,32 20,26 12,12 26,20" />
        <circle cx="32" cy="32" r="10" fill="#3a1a5a" />
        <circle cx="32" cy="32" r="4" fill="#ff2a4a" />
      </g>
      <g stroke="#5a2a8a" strokeWidth="1" fill="none">
        <path d="M32 14 L32 4 M32 50 L32 60 M14 32 L4 32 M50 32 L60 32" />
      </g>
    </svg>
  );
}

type Virus = { id: number; x: number; y: number; vx: number; vy: number; hp: number };
type Pop = { id: number; x: number; y: number; text: string };
type Blinkie = { id: number; src: string; left: number; top: number; width: number; rotate: number };

const PANPAGE_NAMES = [
  "My Chemical Romance",
  "Fall Out Boy",
  "Panic! At The Disco",
];

const LEVELS = [
  {
    name: "geocities-fanpage.html",
    count: 6,
    speed: 0.6,
    infection: "Mild infection",
    bg: "radial-gradient(circle at top left, #10284f 0%, #03070f 100%)",
    titleColor: "#eef9ff",
  },
  {
    name: "freegames4u.net/click-here",
    count: 8,
    speed: 0.9,
    infection: "Heavy infection",
    bg: "linear-gradient(135deg, #ff8a3d 0%, #ff4d8d 100%)",
  },
  {
    name: "totally-legit-bank.ru",
    count: 10,
    speed: 1.2,
    infection: "CRITICAL",
    bg: "linear-gradient(135deg, #0d9488 0%, #064e3b 100%)",
    titleColor: "#eef9ff",
  },
  {
    name: "search-everywhere.org",
    count: 12,
    speed: 1.5,
    infection: "Phishing attack",
    bg: "radial-gradient(circle at top right, #5b21b6 0%, #0f172a 100%)",
    titleColor: "#eef9ff",
  },
  {
    name: "myspace-promo.html",
    count: 14,
    speed: 1.8,
    infection: "Malware cascade",
    bg: "linear-gradient(135deg, #16a34a 0%, #0f172a 100%)",
  },
];

const CONFETTI = Array.from({ length: 30 }, (_, idx) => {
  const colors = ["#ff4656", "#ffdd57", "#3bf3ff", "#78ff47", "#ff8af4", "#f5a623"];
  return {
    id: idx,
    left: 8 + (idx % 10) * 9,
    delay: (idx % 5) * 0.12,
    color: colors[idx % colors.length],
    width: 4 + (idx % 3) * 2,
    height: 10 + ((idx + 1) % 3) * 2,
    rotate: (idx * 37) % 360,
  };
});

const BLINKIE_URLS = [
  "https://adriansblinkiecollection.neocities.org/stamps/a23.gif",
  "https://adriansblinkiecollection.neocities.org/stamps/a22.gif",
  "https://adriansblinkiecollection.neocities.org/stamps/a24.gif",
  "https://adriansblinkiecollection.neocities.org/stamps/a38.png",
  "https://adriansblinkiecollection.neocities.org/stamps/a57.png",
  "https://adriansblinkiecollection.neocities.org/stamps/j13.png",
  "https://adriansblinkiecollection.neocities.org/stamps/e18.gif",
  "https://adriansblinkiecollection.neocities.org/stamps/e70.jpg",
];

const SHOOT_RANGE = 260;
const HERO_SIZE = 64;
const VIRUS_SIZE = 56;
const VIRUS_SIZE_STEP = 9;
const MAX_LIVES = 5;
const HERO_SPEED = 5;
const ENERGY_STATION_WIDTH = 86;
const ENERGY_STATION_HEIGHT = 124;
const ENERGY_STATION_MARGIN = 18;
const CHARGE_TIME_MS = 1800;
const CHARGE_AMOUNT = 6;

function getEnergyStationBounds(arenaWidth: number, arenaHeight: number) {
  return {
    x: arenaWidth - ENERGY_STATION_WIDTH - ENERGY_STATION_MARGIN,
    y: Math.max(ENERGY_STATION_MARGIN, arenaHeight / 2 - ENERGY_STATION_HEIGHT / 2),
    width: ENERGY_STATION_WIDTH,
    height: ENERGY_STATION_HEIGHT,
  };
}

function rectsOverlap(
  a: { x: number; y: number; width: number; height: number },
  b: { x: number; y: number; width: number; height: number }
) {
  return (
    a.x < b.x + b.width &&
    a.x + a.width > b.x &&
    a.y < b.y + b.height &&
    a.y + a.height > b.y
  );
}

function getVirusSize(hp: number) {
  return VIRUS_SIZE + Math.max(0, hp - 1) * VIRUS_SIZE_STEP;
}

function createBlinkies() {
  const safeSpots = [
    { left: [52, 80], top: [8, 22] },
    { left: [8, 32], top: [26, 46] },
    { left: [38, 60], top: [31, 49] },
    { left: [7, 28], top: [58, 78] },
    { left: [34, 58], top: [68, 84] },
    { left: [62, 78], top: [70, 86] },
  ];
  const shuffled = [...BLINKIE_URLS].sort(() => Math.random() - 0.5);

  return shuffled.map((src, idx) => {
    const spot = safeSpots[idx % safeSpots.length];
    return {
      id: idx,
      src,
      left: spot.left[0] + Math.random() * (spot.left[1] - spot.left[0]),
      top: spot.top[0] + Math.random() * (spot.top[1] - spot.top[0]),
      width: 82 + Math.random() * 26,
      rotate: -8 + Math.random() * 16,
    };
  });
}

function Game() {
  const [screen, setScreen] = useState<"boot" | "intro" | "play" | "win" | "lose">("boot");
  const [levelIdx, setLevelIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [bullets, setBullets] = useState(12);
  const [lives, setLives] = useState(MAX_LIVES);
  const [viruses, setViruses] = useState<Virus[]>([]);
  const [pops, setPops] = useState<Pop[]>([]);
  const [ray, setRay] = useState<{ x1: number; y1: number; x2: number; y2: number } | null>(null);
  const [killed, setKilled] = useState(0);
  const [hero, setHero] = useState({ x: 80, y: 320 });
  const [hurt, setHurt] = useState(false);
  const [panpageIndex, setPanpageIndex] = useState(0);
  const [charging, setCharging] = useState(false);
  const [chargeProgress, setChargeProgress] = useState(0);
  const [blinkies, setBlinkies] = useState<Blinkie[]>([]);
  const arenaRef = useRef<HTMLDivElement>(null);
  const idRef = useRef(1);
  const keysRef = useRef<Record<string, boolean>>({});
  const touchingVirusRef = useRef(false);
  const chargeStartRef = useRef<number | null>(null);

  const level = LEVELS[levelIdx];

  useEffect(() => {
    if (screen === "boot") {
      const t = setTimeout(() => setScreen("intro"), 2200);
      return () => clearTimeout(t);
    }
  }, [screen]);

  const startLevel = useCallback((idx: number) => {
    const lvl = LEVELS[idx];
    const arena = arenaRef.current;
    if (!arena) return;
    const w = arena.clientWidth;
    const h = arena.clientHeight;
    const list: Virus[] = [];
    const maxHp = 1 + idx;
    for (let i = 0; i < lvl.count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const hp = 1 + Math.floor(Math.random() * maxHp);
      const size = getVirusSize(hp);
      // spawn away from hero
      let x = 0, y = 0, tries = 0;
      do {
        x = Math.random() * Math.max(1, w - size - 40) + 20;
        y = Math.random() * Math.max(1, h - size - 100) + 20;
        tries++;
      } while (tries < 10 && Math.hypot(x - 80, y - 320) < 150);
      list.push({
        id: idRef.current++,
        x, y,
        vx: Math.cos(angle) * lvl.speed,
        vy: Math.sin(angle) * lvl.speed,
        hp,
      });
    }
    setViruses(list);
    setKilled(0);
    setBullets(12 + idx * 4);
    setLives(MAX_LIVES);
    setCharging(false);
    setChargeProgress(0);
    setBlinkies(createBlinkies());
    chargeStartRef.current = null;
    touchingVirusRef.current = false;
  }, []);

  useEffect(() => {
    if (screen === "play") startLevel(levelIdx);
  }, [screen, levelIdx, startLevel]);

  // keyboard input
  useEffect(() => {
    if (screen !== "play") return;
    const down = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = true;
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(e.key.toLowerCase())) {
        e.preventDefault();
      }
    };
    const up = (e: KeyboardEvent) => { keysRef.current[e.key.toLowerCase()] = false; };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [screen]);

  // physics + movement + collision loop
  useEffect(() => {
    if (screen !== "play") return;
    let raf = 0;
    const tick = () => {
      const arena = arenaRef.current;
      if (arena) {
        const w = arena.clientWidth;
        const h = arena.clientHeight;

        // hero movement
        setHero((p) => {
          const k = keysRef.current;
          let dx = 0, dy = 0;
          if (k["arrowleft"] || k["a"]) dx -= 1;
          if (k["arrowright"] || k["d"]) dx += 1;
          if (k["arrowup"] || k["w"]) dy -= 1;
          if (k["arrowdown"] || k["s"]) dy += 1;
          if (dx === 0 && dy === 0) return p;
          const len = Math.hypot(dx, dy) || 1;
          const nx = Math.max(0, Math.min(w - HERO_SIZE, p.x + (dx / len) * HERO_SPEED));
          const ny = Math.max(0, Math.min(h - HERO_SIZE, p.y + (dy / len) * HERO_SPEED));
          return { x: nx, y: ny };
        });

        setViruses((vs) =>
          vs.map((v) => {
            let { x, y, vx, vy } = v;
            const size = getVirusSize(v.hp);
            x += vx;
            y += vy;
            if (x < 20 || x > w - size - 20) vx = -vx;
            if (y < 20 || y > h - size - 20) vy = -vy;
            return { ...v, x, y, vx, vy };
          })
        );

        // collision check using current state via functional update trick
        setHero((heroPos) => {
          const now = Date.now();
          const station = getEnergyStationBounds(w, h);
          const isAtStation = rectsOverlap(
            { x: heroPos.x, y: heroPos.y, width: HERO_SIZE, height: HERO_SIZE },
            station
          );

          if (isAtStation) {
            const started = chargeStartRef.current ?? now;
            const elapsed = now - started;
            chargeStartRef.current = started;
            setCharging(true);
            setChargeProgress(Math.min(1, elapsed / CHARGE_TIME_MS));

            if (elapsed >= CHARGE_TIME_MS) {
              setBullets((b) => b + CHARGE_AMOUNT);
              chargeStartRef.current = now;
              setChargeProgress(0);
              const pid = idRef.current++;
              setPops((p) => [
                ...p,
                { id: pid, x: station.x + 8, y: station.y - 8, text: `+${CHARGE_AMOUNT} charge` },
              ]);
              setTimeout(() => setPops((p) => p.filter((x) => x.id !== pid)), 800);
            }
          } else {
            chargeStartRef.current = null;
            setCharging(false);
            setChargeProgress(0);
          }

          setViruses((vs) => {
            const hx = heroPos.x + HERO_SIZE / 2;
            const hy = heroPos.y + HERO_SIZE / 2;
            const hit = vs.some((v) => {
              const size = getVirusSize(v.hp);
              const vx = v.x + size / 2;
              const vy = v.y + size / 2;
              return Math.hypot(hx - vx, hy - vy) < (HERO_SIZE + size) / 2 - 10;
            });
            if (!hit) touchingVirusRef.current = false;
            if (hit && !touchingVirusRef.current) {
              touchingVirusRef.current = true;
              setHurt(true);
              setTimeout(() => setHurt(false), 500);
              setLives((l) => Math.max(0, l - 1));
              const pid = idRef.current++;
              setPops((p) => [...p, { id: pid, x: heroPos.x, y: heroPos.y - 10, text: "-1 life!" }]);
              setTimeout(() => setPops((p) => p.filter((x) => x.id !== pid)), 800);
            }
            return vs;
          });
          return heroPos;
        });
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [screen]);

  // check win/lose
  useEffect(() => {
    if (screen !== "play") return;
    if (viruses.length === 0 && killed > 0) {
      if (levelIdx >= LEVELS.length - 1) setScreen("win");
      else setLevelIdx((i) => i + 1);
    }
    if (lives <= 0) setScreen("lose");
  }, [viruses, lives, killed, levelIdx, screen]);

  const shoot = (e: React.MouseEvent<HTMLDivElement>, virus: Virus) => {
    e.stopPropagation();
    const hx = hero.x + HERO_SIZE / 2;
    const hy = hero.y + HERO_SIZE / 2;
    const virusSize = getVirusSize(virus.hp);
    const vx = virus.x + virusSize / 2;
    const vy = virus.y + virusSize / 2;
    if (Math.hypot(hx - vx, hy - vy) > SHOOT_RANGE) return;

    const tx = virus.x + virusSize / 2;
    const ty = virus.y + virusSize / 2;
    setRay({ x1: hero.x + 30, y1: hero.y + 20, x2: tx, y2: ty });
    setTimeout(() => setRay(null), 120);
    setBullets((b) => Math.max(0, b - 1));

    setViruses((vs) => {
      const found = vs.find((v) => v.id === virus.id);
      if (!found) return vs;
      const newHp = found.hp - 1;
      if (newHp <= 0) {
        setScore((s) => s + 100);
        setBullets((b) => b + 2);
        setKilled((k) => k + 1);
        const pid = idRef.current++;
        setPops((p) => [...p, { id: pid, x: virus.x, y: virus.y, text: "+100" }]);
        setTimeout(() => setPops((p) => p.filter((x) => x.id !== pid)), 800);
        return vs.filter((v) => v.id !== virus.id);
      }
      return vs.map((v) => (v.id === virus.id ? { ...v, hp: newHp } : v));
    });
  };

  const resetGame = () => {
    setScore(0);
    setLevelIdx(0);
    setLives(MAX_LIVES);
    setHero({ x: 80, y: 320 });
    setPanpageIndex((i) => (i + 1) % PANPAGE_NAMES.length);
    setScreen("play");
  };

  if (screen === "boot") {
    return (
      <div className="min-h-screen bg-black text-[#b4f0a0] flex items-center justify-center p-8" style={{ fontFamily: "Courier New, monospace" }}>
        <div className="max-w-2xl space-y-2 text-sm md:text-base">
          <div>MalwareBuster BIOS v2.0.1995 — Copyright (C) NetGuard Co.</div>
          <div>Checking system integrity...... <span className="text-white">OK</span></div>
          <div>Loading anti-virus modules... <span className="text-white">OK</span></div>
          <div>Establishing dial-up connection... <span className="text-[#ff7777]">FAILED 3x</span></div>
          <div>Retrying... <span className="text-white">OK</span></div>
          <div>Booting MalwareBuster 95<span className="blink">_</span></div>
        </div>
      </div>
    );
  }

  if (screen === "intro") {
    return (
      <div className="min-h-screen p-4 md:p-10 flex items-center justify-center" style={{ background: "var(--color-desktop)" }}>
        <div className="w-full max-w-xl shadow-[4px_4px_0_rgba(0,0,0,0.4)]">
          <div className="win-bevel">
            <div className="titlebar">
              <span>⚠ Internet Wizard — System Alert</span>
              <div className="flex">
                <button className="titlebar-btn">_</button>
                <button className="titlebar-btn">□</button>
                <button className="titlebar-btn">×</button>
              </div>
            </div>
            <div className="p-4 flex gap-4">
              <div className="w-24 h-24 win-bevel-in flex items-center justify-center shrink-0">
                <div className="text-4xl">🌐</div>
              </div>
              <div className="flex-1 text-sm leading-relaxed">
                <h1 className="text-lg font-bold mb-2">Welcome to MalwareBuster 95!</h1>
                <p className="mb-2">
                  As malware began to flood the Internet, NetGuard Co. created tiny AI companions to fight viruses.
                  You are <b>Zix</b>, a green alien armed with a pastel ray gun.
                </p>
                <p className="mb-2">
                  Move with <b>WASD</b> or <b>Arrow keys</b>. Click viruses to blast them.
                  You have <b>5 lives</b> — don't let viruses touch you!
                </p>
                <p>
                  When your ray gun runs low, stand at the <b>ENERGY</b> station on the right side of the page
                  for a couple of moments. Once it fills up, your bullets recharge and you can jump back into the fight.
                </p>
              </div>
            </div>
            <div className="p-3 flex justify-end gap-2 win-bevel border-t-2" style={{ borderTopColor: "var(--color-win-shadow)" }}>
              <button className="win-btn" onClick={resetGame}>Next &gt;</button>
              <button className="win-btn">Help</button>
              <button className="win-btn">Cancel</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (screen === "win" || screen === "lose") {
    const win = screen === "win";
    return (
      <div className="min-h-screen flex items-center justify-center p-6" style={{ background: "var(--color-desktop)" }}>
        <div className="w-full max-w-md shadow-[4px_4px_0_rgba(0,0,0,0.4)] relative overflow-hidden">
          {win && (
            <div className="confetti-holder">
              {CONFETTI.map((piece) => (
                <span
                  key={piece.id}
                  className="confetti-piece"
                  style={{
                    left: `${piece.left}%`,
                    width: piece.width,
                    height: piece.height,
                    background: piece.color,
                    animationDelay: `${piece.delay}s`,
                    transform: `rotate(${piece.rotate}deg)`,
                  }}
                />
              ))}
            </div>
          )}
          <div className="win-bevel">
            <div className="titlebar">
              <span>{win ? "✓ Mission Complete" : "✗ System Compromised"}</span>
              <div className="flex"><button className="titlebar-btn">×</button></div>
            </div>
            <div className="p-6 text-center">
              <div className="text-5xl mb-3">{win ? "🏆" : "💀"}</div>
              <h2 className="text-xl font-bold mb-2">
                {win ? "The Internet is safe!" : "The web has been overrun."}
              </h2>
              <p className="text-sm mb-4">
                {win ? "You've been promoted to Senior Malware Fighter." : "Viruses have stolen everyone's GeoCities passwords."}
              </p>
              <p className="text-sm mb-4">Final Score: <b>{score}</b></p>
              <button className="win-btn" onClick={resetGame}>Try Again</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-2 md:p-4" style={{ background: "var(--color-desktop)" }}>
      <div className="max-w-6xl mx-auto shadow-[4px_4px_0_rgba(0,0,0,0.5)]">
        <div className="win-bevel">
          <div className="titlebar">
            <span>🛡 NetScape Navigator — [{level.name}]</span>
            <div className="flex">
              <button className="titlebar-btn">_</button>
              <button className="titlebar-btn">□</button>
              <button className="titlebar-btn">×</button>
            </div>
          </div>
          <div className="px-2 py-1 text-xs flex gap-3 border-b" style={{ borderColor: "var(--color-win-shadow)" }}>
            <span><u>F</u>ile</span><span><u>E</u>dit</span><span><u>V</u>iew</span><span><u>G</u>o</span><span><u>B</u>ookmarks</span><span><u>H</u>elp</span>
          </div>
          <div className="p-2 flex flex-wrap gap-2 items-center">
            <button className="win-btn text-xs">◀ Back</button>
            <button className="win-btn text-xs">Forward ▶</button>
            <button className="win-btn text-xs">⟲ Reload</button>
            <button className="win-btn text-xs">⌂ Home</button>
            <div className="flex-1 flex items-center gap-2 min-w-[200px]">
              <span className="text-xs">Address:</span>
              <div className="flex-1 win-bevel-in px-2 py-1 text-xs font-mono truncate">
                http://www.{level.name}
              </div>
            </div>
          </div>

          <div className="px-3 py-2 flex flex-wrap gap-3 items-center text-xs border-y" style={{ borderColor: "var(--color-win-shadow)" }}>
            <span className="win-bevel-in px-2 py-1">SCORE: <b>{score}</b></span>
            <span className="win-bevel-in px-2 py-1">
              BULLETS: <b style={{ color: bullets <= 3 ? "#c00" : "inherit" }}>{bullets}</b>
            </span>
            <span className="win-bevel-in px-2 py-1">
              LIVES: <b>{"♥".repeat(lives)}<span style={{ opacity: 0.3 }}>{"♥".repeat(MAX_LIVES - lives)}</span></b>
            </span>
            <span className="win-bevel-in px-2 py-1">VIRUSES: <b>{viruses.length}</b></span>
            <span className="win-bevel-in px-2 py-1">LEVEL {levelIdx + 1}/{LEVELS.length}</span>
            <span className="ml-auto px-2 py-1 font-bold" style={{ color: "var(--color-titlebar)" }}>{level.infection}</span>
          </div>

          <div
            ref={arenaRef}
            className="relative crt-scan overflow-hidden select-none"
            style={{
              height: "70vh",
              minHeight: 480,
              background: level.bg,
              cursor: bullets > 0 ? "crosshair" : "not-allowed",
            }}
            tabIndex={0}
          >
            <div className="absolute inset-0 p-6 pointer-events-none">
              <h1 className="text-2xl font-bold" style={{ color: level.titleColor ?? "var(--color-titlebar)" }}>
                ★ Welcome to {level.name === "geocities-fanpage.html" ? PANPAGE_NAMES[panpageIndex] : level.name} ★
              </h1>
              <p className="text-sm mt-1 underline text-blue-700">Click here for FREE prizes!!!</p>
              <div className="mt-4 grid grid-cols-3 gap-3 max-w-md">
                <div className="win-bevel-in p-2 text-xs">📁 downloads</div>
                <div className="win-bevel-in p-2 text-xs">💿 install.exe</div>
                <div className="win-bevel-in p-2 text-xs">🗑 trash</div>
              </div>
              <div className="absolute top-2 right-3 text-[10px] font-mono opacity-70">
                Move: WASD / Arrows · Click viruses to shoot
              </div>
              <div className="absolute bottom-6 left-6 right-6 text-[10px] font-mono opacity-60 glitch">
                system alert!!! warning!!! unknownVIRUS!!! alert[alert]./alert!!.;'fd'alertt;klg
              </div>
              {blinkies.map((blinkie) => (
                <img
                  key={`${levelIdx}-${blinkie.id}-${blinkie.src}`}
                  src={blinkie.src}
                  alt=""
                  className="absolute select-none opacity-90"
                  style={{
                    left: `${blinkie.left}%`,
                    top: `${blinkie.top}%`,
                    width: blinkie.width,
                    transform: `translate(-50%, -50%) rotate(${blinkie.rotate}deg)`,
                    imageRendering: "pixelated",
                  }}
                  draggable={false}
                />
              ))}
            </div>

            <div
              className="absolute z-10 win-bevel p-2 text-center"
              style={{
                right: ENERGY_STATION_MARGIN,
                top: "50%",
                width: ENERGY_STATION_WIDTH,
                height: ENERGY_STATION_HEIGHT,
                transform: "translateY(-50%)",
                background: charging
                  ? "linear-gradient(180deg, #b4f0a0 0%, #d8d8e4 100%)"
                  : "var(--color-win)",
                boxShadow: charging
                  ? "0 0 18px rgba(180,240,160,0.8), inset -1px -1px 0 var(--color-win-shadow), inset 1px 1px 0 var(--color-win)"
                  : undefined,
              }}
            >
              <div className="text-[10px] font-bold leading-tight">ENERGY</div>
              <div className="mt-1 win-bevel-in h-16 relative overflow-hidden bg-black">
                <div
                  className="absolute bottom-0 left-0 right-0 transition-[height]"
                  style={{
                    height: `${Math.round(chargeProgress * 100)}%`,
                    background: "linear-gradient(180deg, #ffffff 0%, var(--color-ray) 45%, #4f8a3f 100%)",
                  }}
                />
                <div className="absolute inset-0 flex items-center justify-center text-[22px]">⚡</div>
              </div>
              <div className="mt-1 text-[9px] font-mono leading-tight">
                {charging ? "CHARGING" : "STANDBY"}
              </div>
            </div>

            <div
              className="absolute z-10 pointer-events-none transition-opacity"
              style={{
                left: hero.x,
                top: hero.y,
                opacity: hurt ? 0.4 : 1,
                filter: hurt ? "drop-shadow(0 0 8px #ff2a4a)" : "none",
              }}
            >
              <HeroSprite size={HERO_SIZE} />
            </div>

            {ray && (
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-20">
                <line
                  x1={ray.x1} y1={ray.y1} x2={ray.x2} y2={ray.y2}
                  stroke="var(--color-ray)" strokeWidth="4" strokeLinecap="round"
                  style={{ filter: "drop-shadow(0 0 6px var(--color-ray))" }}
                />
                <line x1={ray.x1} y1={ray.y1} x2={ray.x2} y2={ray.y2} stroke="white" strokeWidth="1.5" />
              </svg>
            )}

            {viruses.map((v) => (
              <div
                key={v.id}
                className="absolute virus-wobble z-10"
                style={{
                  left: v.x,
                  top: v.y,
                  width: getVirusSize(v.hp),
                  height: getVirusSize(v.hp),
                }}
                onClick={(e) => bullets > 0 && shoot(e, v)}
              >
                <VirusBlob size={getVirusSize(v.hp)} />
                {v.hp > 1 && (
                  <div className="absolute -top-3 left-0 right-0 text-center text-[10px] font-bold text-red-700">
                    HP {v.hp}
                  </div>
                )}
              </div>
            ))}

            {pops.map((p) => (
              <div
                key={p.id}
                className="absolute float-up font-bold text-sm pointer-events-none z-30"
                style={{ left: p.x, top: p.y, color: p.text.startsWith("+") ? "#0a8a0a" : "#c0392b" }}
              >
                {p.text}
              </div>
            ))}
          </div>

          <div className="px-2 py-1 text-[11px] flex justify-between border-t" style={{ borderColor: "var(--color-win-shadow)" }}>
            <span>Done — connected via 56k modem</span>
            <span>🔒 Secure (mostly)</span>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto mt-2 win-bevel p-1 flex items-center gap-2">
        <button className="win-btn font-bold text-xs">⊞ Start</button>
        <div className="win-bevel-in px-2 py-1 text-xs flex-1 truncate">🛡 MalwareBuster — {level.name}</div>
        <div className="win-bevel-in px-2 py-1 text-xs">{new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</div>
      </div>
    </div>
  );
}
